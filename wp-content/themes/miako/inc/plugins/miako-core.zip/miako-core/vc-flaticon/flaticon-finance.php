<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

$flaticons_finance = array(
    array( 'flaticon-finance-money-1' => 'flaticon-finance-money-1' ),
    array( 'flaticon-finance-avatar' => 'flaticon-finance-avatar' ),
    array( 'flaticon-finance-open-book' => 'flaticon-finance-open-book' ),
    array( 'flaticon-finance-chart' => 'flaticon-finance-chart' ),
    array( 'flaticon-finance-atomic' => 'flaticon-finance-atomic' ),
    array( 'flaticon-finance-time' => 'flaticon-finance-time' ),
    array( 'flaticon-finance-money' => 'flaticon-finance-money' ),
    array( 'flaticon-finance-support' => 'flaticon-finance-support' ),
    array( 'flaticon-finance-get-money' => 'flaticon-finance-get-money' ),
    array( 'flaticon-finance-piggy-bank' => 'flaticon-finance-piggy-bank' ),
    array( 'flaticon-finance-rich' => 'flaticon-finance-rich' ),
    array( 'flaticon-finance-notes' => 'flaticon-finance-notes' ),
    array( 'flaticon-finance-graph' => 'flaticon-finance-graph' )
);